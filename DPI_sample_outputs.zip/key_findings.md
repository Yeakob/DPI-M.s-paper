# Key findings (auto-generated)

- Panel: 5,162 SKUs; 67 stale snapshot days removed; 56 gap blocks, 317 missing days, longest 137 days (missingness is system-wide: True).
- Reconstruction: preferred = Sticky step (midpoint); alternative = Linear (masked-gap validation, Module 5).
- Food DPI (B): annualised 2.04%; mean YoY 2.37% (range across A–D/MI scenarios: 2.33–2.37%).
- Stickiness: 3.11% of SKUs change price per day; median implied duration 69 days; FK synchronisation 0.06; 9.1% of changes occur on the 5% most synchronised days.
- Regimes: k = 5 (+ no-change regime); bootstrap ARI 0.95; Cramér's V with category 0.27.
- Forecasting (food DPI, h=30): best = ETS (RMSE ratio vs naive 1.01).
- Official CPI linkage: skipped – no CPI data.